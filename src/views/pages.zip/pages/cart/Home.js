import React from "react";
import{
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CRow
} from "@coreui/react";

const Home = () => {
  return(
    <CRow alignHorizontal='center'>
      <CCol xs="12" md='10'>
        <CCard>
          <CCardHeader>
            My Shopping Cart
          </CCardHeader>
          <CCardBody>
            <CRow>
              <CCol xs='1'>
              </CCol>
                dddd<br/>
                cccc<br/>
                bbbb<br/>
                aaaa<br/>
            </CRow>
          </CCardBody>
        </CCard>
      </CCol>
  </CRow>
  )
}

export default Home
