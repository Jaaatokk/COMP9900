import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import {
  CCard,
  CCardBody,
  CCardHeader,
  CCollapse,
  CDropdownItem,
  CDropdownMenu,
  CDropdownToggle,
  CNavbar,
  CNavbarNav,
  CNavbarBrand,
  CToggler,
  CNavLink,
  CDropdown,
  CForm,
  CInput,
  CButton,
  CPagination,
  CCardFooter
} from '@coreui/react'



const Homepage = () => {
  const [isOpen, setIsOpen] = useState(false)
  // const [isOpenDropdown, setIsOpenDropdown] = useState(false)


  return (
    <>
      <CCardHeader>
        <CCardBody>
          <CNavbar expandable="sm" color="info" >
            <CToggler inNavbar onClick={() => setIsOpen(!isOpen)}/>
            <CNavbarBrand>
              Marvelous
            </CNavbarBrand>
            <CCollapse show={isOpen} navbar>
              <CNavbarNav>
                <CNavLink>Home</CNavLink>
                <CNavLink>Link1</CNavLink>
                <CNavLink>Link2</CNavLink>
                <CNavLink>Link3</CNavLink>
                <CNavLink>Link4</CNavLink>
                <CNavLink>Link5</CNavLink>
              </CNavbarNav>
              <Link to ='/cart'>
                <CButton color='light' className="my-2 my-sm-0" >Cart</CButton>
              </Link>


              <CNavbarNav className="ml-auto">
                <CForm inline>
                  <CInput
                    className="mr-sm-2"
                    placeholder="Search Items"
                    size="sm"
                  />
                  <CButton color="light" className="my-2 my-sm-0" type="submit">Search</CButton>
                </CForm>
                <CDropdown
                  inNav
                >
                  <CDropdownToggle color="primary">
                    Language
                  </CDropdownToggle>
                  <CDropdownMenu>
                    <CDropdownItem>EN</CDropdownItem>
                    <CDropdownItem>ES</CDropdownItem>
                    <CDropdownItem>RU</CDropdownItem>
                    <CDropdownItem>FA</CDropdownItem>
                  </CDropdownMenu>
                </CDropdown>
                <CDropdown
                  inNav
                >
                  <CDropdownToggle color="primary">
                    User
                  </CDropdownToggle>
                  <CDropdownMenu>
                    <CDropdownItem>Account</CDropdownItem>
                    <CDropdownItem>Settings</CDropdownItem>
                  </CDropdownMenu>
                </CDropdown>
              </CNavbarNav>
            </CCollapse>
          </CNavbar>
        </CCardBody>
      </CCardHeader>


      {/*<CCardBody>*/}

      {/*  /!*<CCardBody>*!/*/}
      {/*  /!*  <div className="red" > TOP RECOMMENDED</div>*!/*/}
      {/*  /!*  <CNavbar color="faded" light>*!/*/}
      {/*  /!*    <CNavbarBrand>*!/*/}
      {/*  /!*      <CImg*!/*/}
      {/*  /!*        src="https://placekitten.com/g/30/30"*!/*/}
      {/*  /!*        className="d-inline-block align-top"*!/*/}
      {/*  /!*        alt="CoreVue"*!/*/}
      {/*  /!*      />*!/*/}
      {/*  /!*      xiyouji*!/*/}
      {/*  /!*    </CNavbarBrand>*!/*/}
      {/*  */}
      {/*  /!*    <CNavbarBrand>*!/*/}
      {/*  /!*      <CImg*!/*/}
      {/*  /!*        src="https://placekitten.com/g/30/30"*!/*/}
      {/*  /!*        className="d-inline-block align-top"*!/*/}
      {/*  /!*        alt="CoreVue"*!/*/}
      {/*  /!*      />*!/*/}
      {/*  /!*      红楼梦*!/*/}
      {/*  /!*    </CNavbarBrand>*!/*/}
      {/*  */}
      {/*  /!*    <CNavbarBrand>*!/*/}
      {/*  /!*      <CImg*!/*/}
      {/*  /!*        src="https://placekitten.com/g/30/30"*!/*/}
      {/*  /!*        className="d-inline-block align-top"*!/*/}
      {/*  /!*        alt="CoreVue"*!/*/}
      {/*  /!*      />*!/*/}
      {/*  /!*      三国演技*!/*/}
      {/*  /!*    </CNavbarBrand >*!/*/}
      {/*  */}
      {/*  /!*    <CNavbarBrand>*!/*/}
      {/*  /!*      <CImg*!/*/}
      {/*  /!*        src="https://placekitten.com/g/30/30"*!/*/}
      {/*  /!*        className="d-inline-block align-top"*!/*/}
      {/*  /!*        alt="CoreVue"*!/*/}
      {/*  /!*      />*!/*/}
      {/*  /!*      C水浒传*!/*/}
      {/*  /!*    </CNavbarBrand>*!/*/}
      {/*  */}
      {/*  /!*    <CNavbarBrand>*!/*/}
      {/*  /!*      <CImg*!/*/}
      {/*  /!*        src="https://placekitten.com/g/30/30"*!/*/}
      {/*  /!*        className="d-inline-block align-top"*!/*/}
      {/*  /!*        alt="CoreVue"*!/*/}
      {/*  /!*      />*!/*/}
      {/*  /!*      金瓶梅*!/*/}
      {/*  /!*    </CNavbarBrand>*!/*/}
      {/*  */}
      {/*  /!*    <CNavbarBrand>*!/*/}
      {/*  /!*      <CImg*!/*/}
      {/*  /!*        src="https://placekitten.com/g/30/30"*!/*/}
      {/*  /!*        className="d-inline-block align-top"*!/*/}
      {/*  /!*        alt="CoreVue"*!/*/}
      {/*  /!*      />*!/*/}
      {/*  /!*      11111*!/*/}
      {/*  /!*    </CNavbarBrand>*!/*/}
      {/*  */}
      {/*  /!*    <CNavbarBrand>*!/*/}
      {/*  /!*      <CImg*!/*/}
      {/*  /!*        src="https://placekitten.com/g/30/30"*!/*/}
      {/*  /!*        className="d-inline-block align-top"*!/*/}
      {/*  /!*        alt="CoreVue"*!/*/}
      {/*  /!*      />*!/*/}
      {/*  /!*      2222*!/*/}
      {/*  /!*    </CNavbarBrand>*!/*/}
      {/*  */}
      {/*  /!*  </CNavbar>*!/*/}
      {/*  /!*  </CCardBody>*!/*/}
      {/*  </CCardBody>*/}
      {/*  */}
      <CCardBody>
        <div>

        </div>
        <br/>
        <div className="divider text-center">
          左边加一个树状导航
        </div>

      </CCardBody>



      <CCard>
        <CCardFooter className= " center" >

        <CCardBody className="text-muted" >

          <CPagination className="row justify-content-center"
            // activePage={currentPage}
            pages={3}
            // onActivePageChange={setCurrentPage}
          />
          <div className="row justify-content-center" >Jump pages</div>
        </CCardBody>
        </CCardFooter>
      </CCard>

    </>
  )
}

export default Homepage
